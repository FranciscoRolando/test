package com.example.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public class FileFragmenter {
    private static final int FRAGMENT_SIZE = 500 * 1024; // 500 KB

    private String filePath;

    public FileFragmenter(String filePath) {
        this.filePath = filePath;
    }

    public List<String> getFragments() {
        List<String> fragments = new ArrayList<>();
        try {
            byte[] fileContent = readFileContent();
            String base64Content = encodeToBase64(fileContent);
            fragments = splitIntoFragments(base64Content);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fragments;
    }

    private byte[] readFileContent() throws IOException {
        File file = new File(filePath);
        byte[] fileContent = new byte[(int) file.length()];
        try (FileInputStream fis = new FileInputStream(file)) {
            fis.read(fileContent);
        }
        return fileContent;
    }

    private String encodeToBase64(byte[] content) {
        return Base64.getEncoder().encodeToString(content);
    }

    private List<String> splitIntoFragments(String base64Content) {
        List<String> fragments = new ArrayList<>();
        for (int i = 0; i < base64Content.length(); i += FRAGMENT_SIZE) {
            int endIndex = Math.min(i + FRAGMENT_SIZE, base64Content.length());
            String fragment = base64Content.substring(i, endIndex);
            fragments.add(fragment);
        }
        return fragments;
    }
}
