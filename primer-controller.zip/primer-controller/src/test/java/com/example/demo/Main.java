package com.example.demo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        String filePath = "C:\\Users\\rolas\\Downloads\\prueba.pdf";
        FileFragmenter fileFragmenter = new FileFragmenter(filePath);

        List<String> fragments = fileFragmenter.getFragments();
        int totalFragments = fragments.size();

        System.out.println("Total fragments: " + totalFragments);

        for (int i = 0; i < totalFragments; i++) {
            String fragment = fragments.get(i);
            System.out.println("Fragment " + (i + 1) + "/" + totalFragments + ":");
            System.out.println(fragment);

            // Aquí puedes enviar el fragmento a tu microservicio
            sendFragmentToMicroservice(i + 1, totalFragments, fragment);
        }
    }

    private static void sendFragmentToMicroservice(int fragmentId, int totalFragments, String fragment) {
        // Implementa la lógica para enviar el fragmento a tu microservicio
        System.out.println("Sending fragment " + fragmentId + "/" + totalFragments + " to microservice...");
        // Aquí puedes usar una biblioteca HTTP como OkHttp o RestTemplate para enviar el fragmento
    }
}
