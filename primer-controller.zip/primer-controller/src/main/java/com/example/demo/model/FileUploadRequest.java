package com.example.demo.model;

public class FileUploadRequest {
    private String file;
    private int fragmentId;
    private int totalFragments;

    // Getters and setters
    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public int getFragmentId() {
        return fragmentId;
    }

    public void setFragmentId(int fragmentId) {
        this.fragmentId = fragmentId;
    }

    public int getTotalFragments() {
        return totalFragments;
    }

    public void setTotalFragments(int totalFragments) {
        this.totalFragments = totalFragments;
    }
}


