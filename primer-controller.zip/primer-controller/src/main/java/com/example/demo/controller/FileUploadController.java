package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.FileUploadRequest;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/upload")
public class FileUploadController {

    @Value("${upload.directory}")
    private String uploadDirectory;

    private Map<Integer, byte[]> fileFragments = new HashMap<>();

    @PostMapping(value = "/", consumes ="application/json",produces = "application/json")
    public ResponseEntity<Map<String, String>> uploadFile(@RequestBody FileUploadRequest request) throws IOException {
        int fragmentId = request.getFragmentId();
        int totalFragments = request.getTotalFragments();

        // Decodificar el fragmento base64 a bytes
        byte[] fileBytes = Base64.getDecoder().decode(request.getFile());

        // Guardar el fragmento en el sistema de archivos
        File fragmentFile = new File(uploadDirectory, "fragment_" + fragmentId + ".bin");
        try (FileOutputStream fos = new FileOutputStream(fragmentFile)) {
            fos.write(fileBytes);
        } catch (IOException e) {
            e.printStackTrace();
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }

        // Verificar si se han recibido todos los fragmentos
        if (fragmentId == totalFragments) {
            // Concatenar todos los fragmentos
            byte[] completeFile = new byte[0];
            for (int i = 1; i <= totalFragments; i++) {
                File currentFragment = new File(uploadDirectory, "fragment_" + i + ".bin");
                byte[] fragmentBytes = Files.readAllBytes(currentFragment.toPath());
                completeFile = concat(completeFile, fragmentBytes);
                currentFragment.delete(); // Eliminar el fragmento después de concatenarlo
            }

            // Guardar el archivo completo en el sistema de archivos
            File uploadedFile = new File(uploadDirectory, "uploaded_file.pdf");
            try (FileOutputStream fos = new FileOutputStream(uploadedFile)) {
                fos.write(completeFile);
            } catch (IOException e) {
                e.printStackTrace();
                return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
            }

            Map<String, String> response = new HashMap<>();
            response.put("message", "File uploaded successfully");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            Map<String, String> response = new HashMap<>();
            response.put("message", "Fragment " + fragmentId + " received");
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
    }

    private byte[] concat(byte[] a, byte[] b) {
        byte[] c = new byte[a.length + b.length];
        System.arraycopy(a, 0, c, 0, a.length);
        System.arraycopy(b, 0, c, a.length, b.length);
        return c;
    }
}
